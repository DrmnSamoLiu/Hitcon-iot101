#include <stdio.h>
#include <stdlib.h>

void main()	/* Just the reverse of Encode(). */
{

	int N = 4096 , F = 18;
	int THRESHOLD = 2;
	int i, j, k, r, c, max;
	unsigned char bt;
	unsigned int flags;
	unsigned int ulPos=0;
	unsigned int ulExpLen=0;
	unsigned char *ucInput;
	unsigned char *text_buf;
	unsigned char ucOutput[50000];
	FILE *config_file;
	FILE *out_file;

	config_file = fopen("config.dat","rb");
	out_file = fopen("decode.dat","wb"); 

	if (config_file == NULL) {
        fprintf(stderr, "cannot open input file\n");
        return 1;
    }

	fseek(config_file, 0L, SEEK_END);
        int inLen = ftell(config_file);
        
    fseek(config_file, 0L, SEEK_SET);
    
    printf("File open success, file size %d\n",inLen);
    

    ucInput = malloc(inLen);
    text_buf = malloc(N+F-1);
    
    for (i = 0, max = inLen; i < max && ( bt = getc(config_file)) != EOF; i++) {
        ucInput[i] = bt;
//	    printf("%d  ",bt);
    }
	fclose(config_file);
	printf("Read to bt success\n");


	for (i = 0; i < N - F; i++)
		text_buf[i] = ' ';
	printf("text_buff init success \n");
	
	
	r = N - F;
	flags = 0;
	while(1) {
	    fflush(stdout);
		if (((flags >>= 1) & 256) == 0) {
			c = ucInput[ulPos++];
			if (ulPos>inLen)
				break;
			flags = c | 0xff00;		/* uses higher byte cleverly */
		}							/* to count eight */
		if (flags & 1) {
			c = ucInput[ulPos++];
			if ( ulPos > inLen )
				break;
			ucOutput[ulExpLen++] = c;
			text_buf[r++] = c;
			r &= (N - 1);
		} else {
		    if ( ulPos > inLen ) break;
			i = ucInput[ulPos++];
			if ( ulPos > inLen ) break;
			j = ucInput[ulPos++];
			if ( ulPos > inLen ) break;

			i |= ((j & 0xf0) << 4);
			j = (j & 0x0f) + THRESHOLD;
			fflush(stdout);
			for (k = 0; k <= j; k++) {
				c = text_buf[(i + k) & (N - 1)];
				ucOutput[ulExpLen++] = c;
				text_buf[r++] = c;
				r &= (N - 1);

			}
		}
	}
	printf("Decode complete \n");
	for(int i = 0; i < 7000; i++){
	if(ucOutput[i]!=EOF){
		printf("%c",ucOutput[i]);
		fwrite(&ucOutput[i],1,sizeof(ucOutput[i]),out_file);
	}
	else{
	    free(ucInput);
	    free(text_buf);
	    fclose(out_file);
		return 0;
	}
}
    fclose(out_file);
    free(ucInput);
    free(text_buf);
	return 0;
}
